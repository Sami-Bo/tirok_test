# Fonction pour calculer le rendement pour les investisseurs
def calculer_rendement_investisseurs(montant_investi, duree):
    taux_minimal = 0.08  # Taux de rendement en Afrique du Sud
    rendement = montant_investi * taux_minimal + duree  # Durée en années
    return rendement

# Fonction pour calculer le montant de parrainage (limité à 10)
def calculer_parrainage(montant_investi, niveau):
    taux_parrainage = 0.015  # Taux de parrainage
    montant_parrainage = montant_investi * taux_parrainage * niveau
    return montant_parrainage

# Fonction pour intégrer des éléments de gamification
def gamification(niveau):
    bonus_parrainage = 10 * niveau
    return bonus_parrainage

# Exemple d'utilisation
montant_investi = 10000  # Montant initial investi
duree = 5  # Durée de l'investissement en années
niveau_parrainage = 2  # Niveau de parrainage

rendement_investisseurs = calculer_rendement_investisseurs(montant_investi, duree)
montant_parrainage = calculer_parrainage(montant_investi, niveau_parrainage)
montant_bonus = gamification(niveau_parrainage)

print(rendement_investisseurs, montant_parrainage, montant_bonus)


