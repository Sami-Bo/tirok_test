class ContratLocationAccession:
    def __init__(self, prix_vente, acompte_initial, duree_contrat):
        self.prix_vente = prix_vente
        self.avoir = acompte_initial
        self.duree_contrat = duree_contrat

    def calculer_paiement_mensuel(self):
        # Calcul du paiement mensuel (très compétitif)
        frais_gestion = 10
        nombre_mois = self.duree_contrat * 12
        paiement_mensuel = ((self.prix_vente - self.avoir) / nombre_mois) + frais_gestion
        return paiement_mensuel

    def effectuer_versement(self, montant):
        # Effectuer un versement mensuel pour augmenter l'avoir
        self.avoir += montant

    def acheter_propriete(self):
        # Acheter la propriété à la fin du contrat
        if self.avoir >= self.prix_vente:
            return "Félicitations, vous avez acheté la propriété !"
        else:
            return "Vous n'avez pas accumulé suffisamment d'avoir pour acheter la propriété."

# Exemple d'utilisation
contrat = ContratLocationAccession(200000, 20000, 10)
paiement_mensuel = contrat.calculer_paiement_mensuel()
print(f"Paiement mensuel : {paiement_mensuel:.2f} euros")

# Effectuer des versements mensuels
contrat.effectuer_versement(1000)
contrat.effectuer_versement(1500)

# Tenter d'acheter la propriété à la fin du contrat
resultat = contrat.acheter_propriete()
print(resultat)